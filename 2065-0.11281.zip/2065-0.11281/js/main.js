//var url='http://192.168.1.66/';
var url = 'http://s2065.wanyuwl.net/';

var unique = '123321';

